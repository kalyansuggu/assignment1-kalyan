package pomPages;

public class Skillraryloginpage {

}
