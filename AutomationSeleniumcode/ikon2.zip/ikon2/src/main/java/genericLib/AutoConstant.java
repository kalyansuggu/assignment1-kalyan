package genericLib;

public interface AutoConstant {
  String propertfilepath="./src/test/resources/data.properties";
  String photopath="./photo/";
}
