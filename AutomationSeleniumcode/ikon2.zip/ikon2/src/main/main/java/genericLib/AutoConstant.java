package genericLib;

public interface AutoConstant {

	String proertyfilePath="./src/test/resources/data.properties";
	String photoPath="./photo/";
	
}
