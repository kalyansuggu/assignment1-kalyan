package scripts;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Test4 {

	@Test
	public void tc4() {
	Reporter.log("Hello java ", true);
}
}
